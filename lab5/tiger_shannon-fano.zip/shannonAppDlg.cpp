// shannonAppDlg.cpp : implementation file
//

#include "stdafx.h"
#include "shannonApp.h"
#include "shannonAppDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShannonAppDlg dialog

CShannonAppDlg::CShannonAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShannonAppDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShannonAppDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_buffer = new unsigned char [4096];
	m_table = NULL;
}

CShannonAppDlg::~CShannonAppDlg()
{
	delete [] m_buffer;

	if (m_table)
		CShannonFanoEncoding::free_table(m_table, m_tableLen);
}

void CShannonAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShannonAppDlg)
	DDX_Control(pDX, IDC_LIST, m_codesList);
	DDX_Control(pDX, IDC_STATIC_SRCLEN, m_srclenStatic);
	DDX_Control(pDX, IDC_STATIC_OUTLEN, m_outlenStatic);
	DDX_Control(pDX, IDC_EDIT_SRC, m_srcEdit);
	DDX_Control(pDX, IDC_EDIT_OUT, m_outEdit);
	DDX_Control(pDX, IDC_BUTTON_DECODE, m_decodeButton);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShannonAppDlg, CDialog)
	//{{AFX_MSG_MAP(CShannonAppDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ENCODE, OnButtonEncode)
	ON_BN_CLICKED(IDC_BUTTON_DECODE, OnButtonDecode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShannonAppDlg message handlers

BOOL CShannonAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CShannonAppDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CShannonAppDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CShannonAppDlg::OnButtonEncode() 
{
	CShannonFanoEncoding	sfe;

	CString			str;
	int				len, i;
	unsigned char	*sz;

	if (m_table)
		sfe.free_table(m_table, m_tableLen);

	m_srcEdit.GetWindowText(str);
	len = str.GetLength();
	sz = new unsigned char[4096];
	wcstombs((char *) sz, str, len + 1);

	memset(m_buffer, 0, 4096);

	str.Format(L"%d", len << 3);
	m_srclenStatic.SetWindowText(str);

	// encode
	m_len = sfe.encode(sz, len, m_buffer, &m_table, &m_tableLen);

	str.Format(L"%d", m_len);
	m_outlenStatic.SetWindowText(str);

	// output bit result
	unsigned char	*t = m_buffer;
	unsigned char	mask = 0x80, s = 7;

	str.Empty();
	for (i = 1; i <= m_len; i++)
	{
		str += (WCHAR) (((*t & mask) >> s) + L'0');

		mask = mask >> 1;
		s--;

		if (mask == 0)
		{
			mask = 0x80;
			t++;
			s = 7;
		}
	}
	m_outEdit.SetWindowText(str);

	WCHAR	szTemp[64];
	m_codesList.AddString(L"----------");
	// output codes
	for (i = 0; i < m_tableLen; i++)
	{
		_itow(m_table[i]->code, szTemp, 2);
		str.Format(L"%C - %s [len - %d] [count - %d]", m_table[i]->atom, szTemp, m_table[i]->len, m_table[i]->count);
		m_codesList.AddString(str);
	}

	m_decodeButton.EnableWindow();

	delete [] sz;
}

void CShannonAppDlg::OnButtonDecode() 
{
	CShannonFanoEncoding	sfe;

	unsigned char	*sz;
	int				len;

	sz = new unsigned char[1024];

	len = sfe.decode(m_buffer, m_len, sz, m_table, m_tableLen);

	TRACE(L"len - %d\n", len);

	sz[len] = '\0';

	CString	str;

	str.Format(L"%S", sz);
	MessageBox(str);

	delete [] sz;

}
