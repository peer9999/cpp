#ifndef _Shannon_Fano_Encoding_
#define _Shannon_Fano_Encoding_

#include "list.h"

typedef unsigned char	uchar;
typedef unsigned short	ushort;
typedef unsigned long	ulong;

// atom's code structure
typedef struct _atom_code
{
	uchar	atom;
	uchar	len;
	ushort	count;
	ulong	code;
}
atom_code;


// ------------------------------------------------------------
// Shannon Fano encoding
//
class CShannonFanoEncoding
{
private:
	atom_code	**m_table;
	ushort		m_tableLen;

	uchar		*m_out;
	uchar		m_pos;
	ulong		m_outlen;

	typedef struct _tree_node
	{
		atom_code			acode;
		struct _tree_node	*left;
		struct _tree_node	*right;
	}
	tree_node;

	tree_node	*m_head;

public:
	ulong encode(uchar *src, int srclen, uchar *out, atom_code ***table, ushort *tlen);
	ulong decode(uchar *src, int srclen, uchar *out, atom_code **table, ushort tlen);

	static void free_table(atom_code **table, ushort len);

private:
	void create_code_table(uchar *src, int srclen);
	void table_quick_sort(ushort left, ushort right);
	void calculate_codes(ushort left, ushort right);
	void flush_code(ulong code, ushort code_len);

	void build_tree();
	void free_tree(tree_node *node);

	void print_tree(tree_node *node);
};


#endif			// _Shannon_Fano_Encoding_
