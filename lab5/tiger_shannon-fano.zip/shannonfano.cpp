// ------------------------------------------------------------
// Shannon Fano Encoding
//
#include "stdafx.h"
#include "shannonfano.h"


// ------------------------------------------------------------
// encode source
//
ulong CShannonFanoEncoding::encode(uchar *src, int srclen, uchar *out, atom_code ***table, ushort *tlen)
{
	atom_code	**ftable = (atom_code **) malloc(256 * sizeof(atom_code *));
	atom_code	*t;
	int			i;

	// create code table
	create_code_table(src, srclen);

	// create full code table
	for (i = 0; i < m_tableLen; i++)
		ftable[m_table[i]->atom] = m_table[i];

	m_out		= out;
	m_pos		= 8;
	m_outlen	= 0;

	// encode
	for (i = 0; i < srclen; i++)
	{
		t = ftable[*src++];

		flush_code(t->code, t->len);
	}

	free(ftable);

	*table	= m_table;
	*tlen	= m_tableLen;

	return m_outlen;
}



// ------------------------------------------------------------
// decode source
//
ulong CShannonFanoEncoding::decode(uchar *src, int srclen, uchar *out, atom_code **table, ushort tlen)
{
	tree_node	*node;
	int			i;
	uchar		mask = 0x80;
	uchar		*t = out;

	m_table		= table;
	m_tableLen	= tlen;

	build_tree();

	node = m_head;

	// walk through encoded bits
	for (i = 0; i < srclen; i++)
	{
		node = ((*src & mask) == 0) ? node->left : node->right;

		// check for the end node
		if (!node->left)
		{
			*out++	= node->acode.atom;
			node	= m_head;
		}

		mask = mask >> 1;

		if (mask == 0)
		{
			mask = 0x80;
			src++;
		}
	}

	free_tree(m_head);

	return out - t;
}



// ------------------------------------------------------------
// create code table
//
void CShannonFanoEncoding::create_code_table(uchar *src, int srclen)
{
	ushort		*codes = (ushort *) malloc(256 * sizeof(ushort));
	atom_code	*pac;
	atom_code	**t;
	int			i;

	// initial byte counts to zero
	memset(codes, 0, 256 * sizeof(ushort));

	// calculate each byte's count
	for (i = srclen - 1; i >= 0; i--)
		codes[*src++] ++;

	// get the number of different atoms
	m_tableLen = 0;

	for (i = 255; i >= 0; i--)
		if (codes[i] != 0)
			m_tableLen++;

	TRACE(L"atoms - %d\n", m_tableLen);

	// create atoms table
	t = m_table = (atom_code **) malloc(m_tableLen * sizeof(atom_code *));

	uchar	z = 0;

	for (i = 0; i < 256; i++)
		if (codes[i] != 0)
		{
			pac = new atom_code;

			pac->atom	= (uchar) i;
			pac->count	= codes[i];
			pac->code	= 0;
			pac->len	= 0;

//			*t++ = pac;
			t[z] = pac;
			z++;
		}

	for (i = 0; i < m_tableLen; i++)
		TRACE(L"%C - %d\n", m_table[i]->atom, m_table[i]->count);

	TRACE(L"sorting ...\n");
	// sort
	table_quick_sort(0, m_tableLen - 1);

	TRACE(L"calculating ...\n");
	// calulate codes
	calculate_codes(0, m_tableLen - 1);

	free(codes);
}



// ------------------------------------------------------------
// free code table
//
void CShannonFanoEncoding::free_table(atom_code **table, ushort len)
{
	ushort		i;

	for (i = 0; i < len; i++)
		delete table[i];

	free(table);
}



// ------------------------------------------------------------
// sort code table
//
void CShannonFanoEncoding::table_quick_sort(ushort left, ushort right)
{
	short		i = left, j = right;
	atom_code	*swap;
	ushort		t = m_table[(i + j) >> 1]->count;

	do
	{
		while (m_table[i]->count < t)
			i++;
		while (t < m_table[j]->count)
			j--;

		if (i <= j)
		{
			swap		= m_table[i];
			m_table[i]	= m_table[j];
			m_table[j]	= swap;

			i++;
			j--;
		}
	}
	while (i <= j);

	if (left < j)
		table_quick_sort(left, j);
	if (i < right)
		table_quick_sort(i, right);
}



// ------------------------------------------------------------
// calculate codes
//
void CShannonFanoEncoding::calculate_codes(ushort left, ushort right)
{
	short		i = left, j = right;
	ulong		lc = 0, rc = 0;

	do
	{
		if (rc <= lc)
		{
			// '0'
			rc += m_table[j]->count;

			m_table[j]->code <<= 1;
			m_table[j]->len++;

			j--;
		}
		else
		{
			// '1'
			lc += m_table[i]->count;

			m_table[i]->code = (m_table[i]->code << 1) | 1;
			m_table[i]->len++;

			i++;
		}
	}
	while (i <= j);

	if (left < --i)
		calculate_codes(left, i);
	if (++j < right)
		calculate_codes(j, right);
}



// ------------------------------------------------------------
// flush bits to the output buffer
//
void CShannonFanoEncoding::flush_code(ulong code, ushort code_len)
{
	m_outlen += code_len;

	// flush some bits
	if (m_pos < code_len)
	{
		do
		{
			*m_out |= (code >> (code_len - m_pos));

			// go to the next output byte
			m_out += 1;

			// reduce code and it`s length
			code_len -= m_pos;
			code &= (0xFFFFFFFF) >> (32 - code_len);

			m_pos = 8;
		}
		while (code_len > m_pos);
	}

	// flush the rest
	*m_out |= (code << (m_pos - code_len));
	m_pos -= code_len;

	// move to the next byte if current is filled up
	if (m_pos == 0)
	{
		m_pos = 8;
		m_out = m_out + 1;
	}
}



// ------------------------------------------------------------
// buil tree
//
void CShannonFanoEncoding::build_tree()
{
	CList<tree_node *>	list;
	tree_node			*ptn, *ptn2, *ptn_parent;
	ushort				i, max = 1;
	ulong				pos, pos2;

	if (m_tableLen == 1)
	{
		ptn		= new tree_node;
		ptn2	= new tree_node;
		m_head	= new tree_node;

		m_head->left	= ptn;
		m_head->right	= ptn2;

		ptn->left = ptn->right = ptn2->left = ptn2->right = NULL;
		ptn->acode.atom = m_table[0]->atom;

		return;
	}

	// create list from code table
	for (i = 0; i < m_tableLen; i++)
	{
		ptn = new tree_node;
		ptn->acode	= *m_table[i];
		ptn->left	= NULL;
		ptn->right	= NULL;

		list.AddTail(ptn);

		if (m_table[i]->len > max)
			max = m_table[i]->len;
	}

	// transform list to tree
	for (i = max; i > 0; i--)
	{
		pos2 = pos = list.GetHead();

		while (list.GetNext(&pos, &ptn))
		{
			if (ptn->acode.len == i)
			{
				// delete the first
				list.DeleteFrom(pos2);

				pos2 = pos;
				// get the second node
				list.GetNext(&pos, &ptn2);
				// delete the second
				list.DeleteFrom(pos2);

				ptn_parent = new tree_node;

				ptn_parent->right	= ptn;
				ptn_parent->left	= ptn2;

				ptn_parent->acode.len	= i - 1;
//				ptn_parent->acode.code	= ptn->acode.code >> 1;
//				ptn_parent->acode.atom	= '?';

				list.InsertBefore(pos, ptn_parent);
			}
			pos2 = pos;
		}
	}
	list.RemoveHead(&m_head);

	print_tree(m_head);
}



// ------------------------------------------------------------
// free tree
//
void CShannonFanoEncoding::free_tree(tree_node *node)
{
	if (node->left)
	{
		free_tree(node->left);
		free_tree(node->right);
	}
	delete node;
}



void CShannonFanoEncoding::print_tree(tree_node *node)
{
	CString		str;

	TRACE(L"[%C]\n", node->acode.atom);

	if (node->left)
	{
		TRACE(L"L:");
		print_tree(node->left);
		TRACE(L"R:");
		print_tree(node->right);
	}

}
