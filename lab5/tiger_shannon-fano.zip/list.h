#ifndef _Linked_List_
#define _Linked_List_

// ------------------------------------------------------------
// linked list
//
template <class T> class CList
{
private:
	// work structure
	typedef struct _node
	{
		T				data;
		struct _node	*next;
		struct _node	*prev;
	} node;

private:
	node			*m_head, *m_tail;
	unsigned int	m_count;

public:
	CList();
	virtual ~CList();

	unsigned int GetCount() const
		{ return m_count; };

	void AddHead(T data);
	void AddTail(T data);
	void InsertBefore(unsigned long pos, T data);
	void InsertAfter(unsigned long pos, T data);

	bool RemoveHead(T *data);
	bool RemoveTail(T *data);
	bool RemoveFrom(unsigned long pos, T *data);
	void DeleteHead();
	void DeleteTail();
	void DeleteFrom(unsigned long pos);
	void Free();

	const unsigned long GetHead();
	const unsigned long GetTail();
	bool GetNext(unsigned long *pos, T *data);
	bool GetPrev(unsigned long *pos, T *data);
	bool Get(unsigned long pos, T *data);

	bool GetNextPos(unsigned long *pos);
	bool GetPrevPos(unsigned long *pos);
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

template <class T> CList<T>::CList(void)
{
	m_head = m_tail = NULL;
	m_count = 0;
}

template <class T> CList<T>::~CList()
{
	Free();
}



// ------------------------------------------------------------
// add an element to the head of the list
//
template <class T> void CList<T>::AddHead(T data)
{
	node	*pnode = new node;

	pnode->data = data;
	pnode->next = m_head;
	pnode->prev = NULL;

	if (m_head)
		m_head->prev = pnode;
	m_head		= pnode;

	if (!m_tail)
		m_tail	= pnode;

	m_count++;
}



// ------------------------------------------------------------
// add an element to the tail of the list
//
template <class T> void CList<T>::AddTail(T data)
{
	node	*pnode = new node;

	pnode->data	= data;
	pnode->next	= NULL;
	pnode->prev = m_tail;

	if (m_tail)
		m_tail->next = pnode;
	m_tail		= pnode;

	if (!m_head)
		m_head	= pnode;

	m_count++;
}



// ------------------------------------------------------------
// add an element before the specified position
//
template <class T> void CList<T>::InsertBefore(unsigned long pos, T data)
{
	node	*tnode = (node *) pos;
	node	*pnode = NULL;

	if (pos != 0)
	{
		if (!tnode->prev)
		{
			AddHead(data);
			return;
		}

		pnode = new node;

		pnode->data	= data;
		pnode->next	= tnode;
		pnode->prev = tnode->prev;

		tnode->prev->next	= pnode;
		tnode->prev			= pnode;

		m_count++;
	}
	else
		AddTail(data);
}



// ------------------------------------------------------------
// add an element after the specified position
//
template <class T> void CList<T>::InsertAfter(unsigned long pos, T data)
{
	node	*tnode = (node *) pos;
	node	*pnode = NULL;

	if (pos != 0)
	{
		if (!tnode->next)
		{
			AddTail(data);
			return;
		}

		pnode = new node;

		pnode->data	= data;
		pnode->next	= tnode->next;
		pnode->prev = tnode;

		tnode->next->prev	= pnode;
		tnode->next			= pnode;

		m_count++;
	}
}



// ------------------------------------------------------------
// remove an element from the head and return it's value
//
template <class T> bool CList<T>::RemoveHead(T *data)
{
	// check if the list is not empty
	if (m_head)
	{
		*data	= m_head->data;
		DeleteHead();

		return true;
	}
	return false;
}



// ------------------------------------------------------------
// remove an element from the tail and return it's value
//
template <class T> bool CList<T>::RemoveTail(T *data)
{
	node	*pnode;

	// check if the list is not empty
	if (m_tail)
	{
		*data	= m_tail->data;
		DeleteTail();

		return true;
	}
	return false;
}



// ------------------------------------------------------------
// remove an element from specified pos and return it's value
//
template <class T> bool CList<T>::RemoveFrom(unsigned long pos, T *data)
{
	node	*tnode = (node *) pos;

	if (pos != 0)
	{
		if (!tnode->prev)
			return RemoveHead(data);

		if (!tnode->next)
			return RemoveTail(data);

		*data = tnode->data;

		tnode->prev->next = tnode->next;
		tnode->next->prev = tnode->prev;
		delete tnode;

		m_count--;
		return true;
	}
	return false;
}



// ------------------------------------------------------------
// delete an element from the head
//
template <class T> void CList<T>::DeleteHead()
{
	node	*pnode;

	// check if the list is not empty
	if (m_head)
	{
		pnode	= m_head->next;

		delete m_head;

		m_head	= pnode;
		if (!m_head)
			m_tail = NULL;
		else
			m_head->prev = NULL;

		m_count--;
	}
}



// ------------------------------------------------------------
// delete an element from the tail
//
template <class T> void CList<T>::DeleteTail()
{
	node	*pnode;

	// check if the list is not empty
	if (m_tail)
	{
		pnode	= m_tail->prev;

		delete m_tail;

		m_tail = pnode;
		if (!m_tail)
			m_head = NULL;
		else
			m_tail->next = NULL;

		m_count--;
	}
}



// ------------------------------------------------------------
// delete an element from specified pos
//
template <class T> void CList<T>::DeleteFrom(unsigned long pos)
{
	node	*tnode = (node *) pos;

	if (pos != 0)
	{
		if (!tnode->prev)
		{
			DeleteHead();
			return;
		}

		if (!tnode->next)
		{
			DeleteTail();
			return;
		}

		tnode->prev->next = tnode->next;
		tnode->next->prev = tnode->prev;
		delete tnode;

		m_count--;
	}
}



// ------------------------------------------------------------
// free the list
//
template <class T> void CList<T>::Free()
{
	node	*pnode = m_head, *t;

	// walk through the list and delete every element
	while (pnode)
	{
		t = pnode->next;
		delete pnode;
		pnode = t;
	}

	m_head = m_tail = NULL;
	m_count = 0;
}



// ------------------------------------------------------------
// get head's position
//
template <class T> const unsigned long CList<T>::GetHead()
{
	return (unsigned long) m_head;
}



// ------------------------------------------------------------
// get tail's position
//
template <class T> const unsigned long CList<T>::GetTail()
{
	return (unsigned long) m_tail;
}



// ------------------------------------------------------------
// get element's data (element is pointed by pos) and move to the next
//
template <class T> bool	CList<T>::GetNext(unsigned long *pos, T *data)
{
	if (pos && (*pos != 0))
	{
		*data	= ((node *)(*pos))->data;
		*pos	= (unsigned long) ((node *)(*pos))->next;
		return true;
	}
	return false;
}



// ------------------------------------------------------------
// get element's data (element is pointed by pos) and move to the prev
//
template <class T> bool CList<T>::GetPrev(unsigned long *pos, T *data)
{
	if (pos && (*pos != 0))
	{
		*data	= ((node *)(*pos))->data;
		*pos	= (unsigned long) ((node *)(*pos))->prev;
		return true;
	}
	return false;
}



// ------------------------------------------------------------
// get element's data (element is pointed by pos) and move to the prev
//
template <class T> bool CList<T>::Get(unsigned long pos, T *data)
{
	if (pos && (*pos != 0))
	{
		*data	= ((node *)(*pos))->data;
		return true;
	}
	return false;
}



// ------------------------------------------------------------
// get position of the previous element
//
template <class T> bool	CList<T>::GetNextPos(unsigned long *pos)
{
	if (pos && (*pos != 0))
	{
		*pos = (unsigned long) ((node *)(*pos))->next;
		return true;
	}
	return false;
}



// ------------------------------------------------------------
// get position of the next element
//
template <class T> bool	CList<T>::GetPrevPos(unsigned long *pos)
{
	if (pos && (*pos != 0))
	{
		*pos = (unsigned long) ((node *)(*pos))->prev;
		return true;
	}
	return false;
}



#endif			// _Linked_List_