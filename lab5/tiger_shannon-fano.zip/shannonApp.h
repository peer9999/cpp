// shannonApp.h : main header file for the SHANNONAPP application
//

#if !defined(AFX_SHANNONAPP_H__23086DEB_67C3_4D9F_9A4C_F14474D4AD5B__INCLUDED_)
#define AFX_SHANNONAPP_H__23086DEB_67C3_4D9F_9A4C_F14474D4AD5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CShannonAppApp:
// See shannonApp.cpp for the implementation of this class
//

class CShannonAppApp : public CWinApp
{
public:
	CShannonAppApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShannonAppApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CShannonAppApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHANNONAPP_H__23086DEB_67C3_4D9F_9A4C_F14474D4AD5B__INCLUDED_)
