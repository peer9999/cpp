/*

  Syntax analyzer

  Features:
	* simple predictive syntax analysis

*/

#include "global.h"

int lookahead;
token_t tok, nulltoken = {0,NONE,0,0};
int negflag=0;

void parse(void)
{
	lookahead = nexttoken();
	while (stmt() != DONE) {}
	return;
}

int stmt(void)
{
	int out;
	for (;;) {
		switch (lookahead) {
		case ID:  // id = expr;
			emit(LVALUE,&tokenval); 
			match(ID); 
			match(SE); 
			expr();
			match(DOTCOMMA); 
			emit(SE,&nulltoken);
			continue;
		case DEFINE:
			vars();
			continue;
		case IF:  // if (expr) then stmt [else stmt] end
			match(IF); 
			match(ROBRACKET); 
			expr(); 
			match(RCBRACKET);
			out = newlabel();
			charno+=charno*2;
			emit(GOFALSE,gen_token(0,out,0,0));
			match(THEN);
			stmt();
			match(END);
			emit(LABEL,gen_token(0,out,0,0));
			continue;
/*		case ELSE:
			match(ELSE);
			out2 = newlabel();
			emit(GOTO,out2);
			emit(LABEL,out);
			stmt();
			emit(LABEL,out2);
			match(END);
			continue;
*/
		case END:
			return 0;
		case DONE:
			return DONE;
		default:
			error("illegal statement");
			repair(1);
			continue;
		}
	}
	return DONE;
}

void vars()
{
	token_t t;
	match(DEFINE);
	memcpy(&t,&tokenval,sizeof(token_t));
	match(ID);
	match(DOTCOMMA);
	emit(TYPE_DEFAULT,&t);
	return;
}

void expr(void)
{
	int t;
	term();
	for (;;) {
		switch (lookahead) {
		case ADD: case SUB:
			t = lookahead;
			match(lookahead); term(); emit(t,&nulltoken);
			continue;
		default:
			return;
		}
	}
	return;
}

void term(void)
{
	int t;
	factor();
	for (;;) {
		switch (lookahead) {
		case MUL: case DIV: case IDIV: case IMOD:
			t = lookahead;
			match(lookahead); factor(); emit(t,&nulltoken);
			continue;
		default:
			return;
		}
	}
	return;
}

void factor(void)
{
	int ng=0;
	switch (lookahead) {
	case ROBRACKET:
		match(ROBRACKET);
		if (negflag) {
			ng=1; negflag=0;
		}
		expr(); 
		match(RCBRACKET);
		if (ng)
			emit(NEG,&nulltoken);
		break;
	case NUM:
		emit(NUM,&tokenval); 
		match(NUM); 
		if (negflag) {
			emit(NEG,&nulltoken);
			negflag=0;
		}
		break;
	case ID:
		emit(RVALUE,&tokenval);
		match(ID);
		if (negflag) {
			emit(NEG,&nulltoken);
			negflag=0;
		}
		break;
	case SUB:
		match(SUB);
		negflag = 1;
		expr();
		break;
	default:
		error("illegal statement\n");
		repair(1);
	}
	return;
}

void match(int t)
{
	if (lookahead == t)
		lookahead = nexttoken();
	else err_expected(t);
	return;
}

int newlabel(void)
{
	return charno;
}

token_t *gen_token(int type, int ival, double fval, int *pval)
{
	tok.type =	type;
	tok.ivalue = ival;
	tok.fvalue = fval;
	tok.pvalue = pval;
	return &tok;
}
