/* lexical analyzer */

#include "global.h"

// buffer size
// change it if necessary
// use small size to debug
#define BUFF_SIZE	8
#define LEX_SIZE	128

char	lexbuff[LEX_SIZE]; // lexeme buffer
int		lexpos;

int		lineno = 1; // line number
int		charno = 0;

int		laststate = 0;

token_t tokenval = {0,NONE,0,0}; // current token value

char	buff[BUFF_SIZE*2+2]; // double-part buffer
char	*lexeme_start;
char	*forward; // current pointer in buffer
int		useagain = 0; // in some cases you need to use old data in the buffer again
						// in case of fallback when getting the right lexeme in DFA


// initialize
void initlex()
{
	// set EOF in the end of each part of buffer
	buff[BUFF_SIZE] = BEOF;
	buff[BUFF_SIZE*2+1] = BEOF;
	// load first (both) parts
	loadnext(2);
	lexeme_start = buff;
	// set pointer to the beginning of the buffer
	forward = buff;
	return;
}

// calculate buffer length
int bufflen(char *s)
{
	int n = 0;
	while (*s++!=BEOF) {
		if (n++>BUFF_SIZE*2) break;
	}
	return n;
}

int loadnext(int part) // fill one of 2 parts of the buffer
{
	int n,m=0,pos;
	switch (part) {
	case 0:
		pos = ftell(i_file); // get current position
		n = fread(buff,BUFF_SIZE,1,i_file);
		buff[BUFF_SIZE] = BEOF;
		if (n==0) { // if less than BUFF_SIZE bytes read
			// load them again and set EOF in the end
			fseek(i_file,pos,SEEK_SET);
			m=0;
			while (!feof(i_file)) {
				fread(buff+m,sizeof(char),1,i_file);
				m++;
			}
			buff[m-1] = BEOF;
		}
		break;
	case 1:
		pos = ftell(i_file);
		n = fread(buff+BUFF_SIZE+1,BUFF_SIZE,1,i_file);
		buff[BUFF_SIZE*2+1] = BEOF;
		if (n==0) {
			fseek(i_file,pos,SEEK_SET);
			m=0;
			while (!feof(i_file)) {
				fread(buff+BUFF_SIZE+1+m,sizeof(char),1,i_file);
				m++;
			}
			buff[BUFF_SIZE+m] = BEOF;
		}
		break;
	case 2:
		pos = ftell(i_file);
		n = fread(buff,BUFF_SIZE,1,i_file);
		if (n==0) {
			fseek(i_file,pos,SEEK_SET);
			m=0;
			while (!feof(i_file)) {
				fread(buff+m,sizeof(char),1,i_file);
				m++;
			}
			buff[m] = BEOF;
			break;
		}
		buff[BUFF_SIZE] = BEOF;
		buff[BUFF_SIZE*2+1] = BEOF;
		break;
	default:
		return 0;
	}
	return 0;
}

// get next symbol from buffer
int nextch(void)
{
	char c;
	c = *forward;
	if (*forward==BEOF) { // if it is EOF
		// if it's at the end of the first part of buffer
		if (forward == buff+BUFF_SIZE) {
			if (useagain==1) {
				forward++;
				c = *forward;
			} else {
				loadnext(1); // load the second part
				forward++; // move pointer forward
				c = *forward;
			}
			useagain=0;
		} else if (forward == buff+BUFF_SIZE*2+1){ // if at second...
			if (useagain==1) {
				forward = buff;
				c = *forward;
			} else {
				loadnext(0); // load the first part
				forward = buff; // set pointer to the beginning
				c = *forward;
			}
			useagain=0;
		} else { // if it's a real EOF
			c = BEOF; // return it
		}
	}
	forward++; // increase pointer
	charno++;
	if (c==BEOF) return 256;
	return c;
}

int nexttoken(void)
{
	int state = 0;
	int t=0,p=0;
	for (;;) {
		switch (state) {
		case 0: // base state
			t = nextch();
			state = transpass(state,t);
			break;
		case 1: // < or <=
			t = nextch();
			state = transpass(state,t);
			break;
		case 2:
//			printf("<=\n");
			return LE;
			break;
		case 3:
			forward--;
			charno--;
//			printf("<\n");
			return LT;
			break;
		case 4: // = or ==
			t = nextch();
			state = transpass(state,t);
			break;
		case 5:
			printf("==\n");
			return EQ;
			break;
		case 6:
			forward--;
			charno--;
//			printf("=\n");
			return SE;
			break;
		case 7: // > or >=
			t = nextch();
			state = transpass(state,t);
			break;
		case 8:
//			printf(">=\n");
			return GE;
			break;
		case 9:
			forward--;
			charno--;
//			printf(">\n");
			return GT;
			break;
		case 10: // number ( num->digit+(.digit+)?(E(+|-)?digit+)? )
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 11: // point (.)
			lex_add('.');
			t = nextch();
			state = transpass(state,t);
			break;
		case 12:
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 13: // exponent (E)
			lex_add('E');
			t = nextch();
			state = transpass(state,t);
			break;
		case 14:
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 15: // sign (+,-)
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 16:
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 17: // value itself
//			printf("%s\n",lex_gen());
			parse_num(lex_gen(),&tokenval);
			lex_flush();
			forward--;
			charno--;
			return NUM;
			break;
		case 18: // 0x.. 0b...
			lexeme_start = forward-1;
			t = nextch();
			state = transpass(state,t);
			break;
		case 19:
			// this's the case of fallback
			// if lexeme beginning and the current pointer are in different parts of the buffer
			// or it is greater than the current poiner
			// we need to use the preveous part of the buffer again
			if ((lexeme_start > forward) || 
				(lexeme_start<buff+BUFF_SIZE && forward>buff+BUFF_SIZE))
				useagain = 1;
			forward = lexeme_start; // fallback
			t = nextch();
			state = 10; // goto state 10 ( num->digit+(.digit+)?(E(+|-)?digit+)? )
			lex_flush(); // flush temporary lexeme to avoid possible problems
			break;
		case 20: // hexadecimal (0x..)
			t = nextch();
			state = transpass(state,t);
			break;
		case 21:
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 22:
			tokenval.type = TVAL_INT;
			tokenval.ivalue = hex2int(lexbuff);
//			printf("%X (%d)\n",tokenval.ivalue,tokenval.ivalue);
			lex_flush();
			forward--;
			charno--;
			return NUM;
			break;
		case 23: // binary (0b..)
			t = nextch();
			state = transpass(state,t);
			break;
		case 24:
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 25:
			tokenval.type = TVAL_INT;
			tokenval.ivalue = bin2int(lexbuff);
//			printf("%s (%d)\n",lexbuff,tokenval.ivalue);
			lex_flush();
			forward--;
			charno--;
			return NUM;
			break;
		case 26: // identifier
			lex_add((char)t);
			t = nextch();
			state = transpass(state,t);
			break;
		case 27:
			p = lookup(lexbuff); // get lexeme hash (if it's in table)
			if (p == 0) // if not
				p = insert(lexbuff,ID); // add it there
			tokenval.type = 2; // type: ID
			tokenval.ivalue = p; // value - lexeme hash
//			printf("%s\n",get(p)->lexptr);
			lex_flush();
			forward--;
			charno--;
			return get(p)->token; // return lexeme token
			break;
/////////////////////////////////////////////
		case 28: // + or += or ++
			t = nextch();
			state = transpass(state,t);
			break;
		case 29:
//			printf("+=\n");
			return EADD;
			break;
		case 30:
//			printf("++\n");
			return INC;
			break;
		case 31:
			forward--;
			charno--;
//			printf("+\n");
			return ADD;
			break;
		case 32: // - or -= or --
			t = nextch();
			state = transpass(state,t);
			break;
		case 33:
//			printf("-=\n");
			return ESUB;
			break;
		case 34:
//			printf("--\n");
			return DEC;
			break;
		case 35:
			forward--;
			charno--;
//			printf("-\n");
			return SUB;
			break;
		case 36: // * or *=
			t = nextch();
			state = transpass(state,t);
			break;
		case 37:
//			printf("*=\n");
			return EMUL;
			break;
		case 38:
			forward--;
			charno--;
//			printf("*\n");
			return MUL;
			break;
		case 39: // / or /=
			t = nextch();
			state = transpass(state,t);
			break;
		case 40:
//			printf("/=\n");
			return EDIV;
			break;
		case 41:
			forward--;
			charno--;
//			printf("/\n");
			return DIV;
			break;
		case 42: // & or &= or &&
			t = nextch();
			state = transpass(state,t);
			break;
		case 43:
//			printf("&=\n");
			return ECON;
			break;
		case 44:
//			printf("&&\n");
			return AND;
			break;
		case 45:
			forward--;
			charno--;
//			printf("&\n");
			return CON;
			break;
		case 46: // | or |= or ||
			t = nextch();
			state = transpass(state,t);
			break;
		case 47:
//			printf("|=\n");
			return EDIS;
			break;
		case 48:
//			printf("||\n");
			return OR;
			break;
		case 49:
			forward--;
			charno--;
//			printf("|\n");
			return DIS;
			break;
		case 50:
//			printf("(\n");
			return ROBRACKET;
			break;
		case 51:
//			printf("[\n");
			return SOBRACKET;
			break;
		case 52:
//			printf("{\n");
			return FOBRACKET;
			break;
		case 53:
//			printf(")\n");
			return RCBRACKET;
			break;
		case 54:
//			printf("]\n");
			return SCBRACKET;
			break;
		case 55:
//			printf("}\n");
			return FCBRACKET;
			break;
		case 56:
//			printf(".\n");
			return DOT;
			break;
		case 57:
//			printf(",\n");
			return COMMA;
			break;
		case 58:
//			printf(";\n");
			return DOTCOMMA;
			break;
		case 59:
//			printf("\\\n");
			return BACKSLASH;
			break;
		case 60:
//			printf("\'\n");
			return QUOTE;
			break;
		case 61:
//			printf("\"\n");
			return DQUOTE;
			break;
////////////////////////
		case 254: // error state
			switch (laststate) { // recognize error by the last state
			case 10:
				error("Invalid symbols in numeric definition");
				break;
			case 11:
				error("Invalid symbols in numeric definition");
				break;
			case 12:
				error("Invalid symbols in numeric definition");
				break;
			case 13:
				error("Invalid symbols after exponent");
				break;
			case 14:
				error("Invalid symbols in numeric definition");
				break;
			case 15:
				error("Invalid symbols after exponent sign");
				break;
			case 16:
				error("Invalid symbols in numeric definition");
				break;
			case 20:
				error("Invalid symbols in hexadecimal value");
				break;
			case 21:
				error("Invalid symbols in hexadecimal value");
				break;
			case 23:
				error("Invalid symbols in binary value");
				break;
			case 24:
				error("Invalid symbols in binary value");
				break;
			default:
				error("Lexical error");
				break;
			}
			break;
		case 255:
			state = 0;
			if ((t == '\n') || (t == '\r')) {
				lineno++;
				charno=0;
			}
			continue;
		case 256:
			return DONE;
			break;
		default:
			error("Invalid symbol");
			break;
		}
	}
	return -1;
}

//
// for getting current lexeme (id or num)
//
void lex_add(char c)
{
	if (lexpos >= LEX_SIZE-1) {
		error("Lexeme is too long");
	}
	lexbuff[lexpos++] = c;
	return;
}

char *lex_gen()
{
	return lexbuff;
}

// flush lex buffer
void lex_flush()
{
	int i;
	for (i=0;i<LEX_SIZE;i++) {
		lexbuff[i]=0;
	}
	lexpos = 0;
	return;
}
//

void parse_num(char *num,token_t *t)
{
	char *s;
	int quot=0,pwr=-1,mul=0,div=10;
	double rem=0,number=0;
	s = num;
	// parse quote first
	while (*s!='.' && *s!='E' && *s!='\0') {
		quot=(quot+(*s-'0'))*10;
		s++;
	}
	quot/=10;
	// then remainer
	if (*s == '.') {
		s++;
		while (*s!='E' && *s!='\0') {
			rem=(rem+(*s-'0'))*10;
			div*=10;
			s++;
		}
		rem = rem/div;
	} 
	// if we need power of value
	if (*s == 'E') {
		s++;
		pwr=0;
		if (*s=='+') {
			mul=1; s++;
		} else if (*s=='-') {
			// if negative power, set attribute (for floats)
			mul=-1; s++;
		} else {
			mul=1;
		}
		while (*s!='\0') { // get power
			pwr=(pwr+(*s-'0'))*10;
			s++;
		}
		pwr/=10; pwr*=mul;
	}
	number = quot+rem; // join two parts
	if (mul!=0) // get power if necessary
		number = pow(number,pwr);
	// save parsed value
	if (rem==0 && mul!=-1) {
		t->type = TVAL_INT;
		t->ivalue = (long int)number;
	} else {
		t->type = TVAL_FLOAT;
		t->fvalue = number;
	}
	return;
}

//