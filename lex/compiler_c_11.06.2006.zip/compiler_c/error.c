#include "global.h"

extern int lookahead;

void error(char *s)
{
	printf("error (line %d:%d): %s\n",lineno,charno,s);
	return;
}

void err_expected(int tok)
{
	char stok[32];
	int reptype = 0;
	memset(stok,0,(size_t)32);
	switch (tok) {
	case DOTCOMMA:
		strncpy(stok,"\";\"",32);
		reptype=2;
		break;
	case SE:
		strncpy(stok,"\"=\"",32);
		break;
	case ROBRACKET:
		strncpy(stok,"\"(\"",32);
		break;
	case RCBRACKET:
		strncpy(stok,"\")\"",32);
		break;
	case ID:
		strncpy(stok,"identifier",32);
		break;
	case THEN:
		strncpy(stok,"\"then\" statement",32);
		reptype=1;
		break;
	case END:
		strncpy(stok,"\"end\" statement",32);
		break;
	default:
		printf("error (line %d:%d): parse error\n",lineno,charno);
		goto rep;
	}
	printf("error (line %d:%d): %s expected\n",lineno,charno,stok);
rep:
	repair(reptype);
}

int repair(int type)
{
	int tok;
	switch (type) {
	case 0:
		while (tok!=DOTCOMMA) {
			tok = nexttoken();
		}
		break;
	case 1:
		lookahead = nexttoken();
		break;
	case 2:
		break;
	}
	return 1;
}
