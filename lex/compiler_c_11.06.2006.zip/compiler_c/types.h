#ifndef __TYPES_H_
#define __TYPES_H_

// finite.c
typedef int	 Dtran_entry_t;
typedef Dtran_entry_t *Dtran_t;
typedef Dtran_t *Dstates_t;


// symbol.c
typedef struct entry_t {		// symbols table entry
	char *lexptr;
	int token;
} entry_t;

// lexer.c
typedef struct token_t {
	int type;
	long int ivalue;
	double fvalue;
	void *pvalue;
} token_t;

// sym_hash.c
typedef void *T;                /* type of item to be stored */
typedef int hash_index_t;     /* index into hash table */
typedef struct hash_node_t_ {
    struct hash_node_t_ *next;         /* next node */
    int id;
	T data;/* data stored in node */
} hash_node_t, **hash_table_t;

#endif