#ifndef __DEFN_H_
#define __DEFN_H_

#define DTRAN_SIZE		257


#define BEOS		'\0'
#define BEOF		0
#define NONE		-1

// token definitions
enum {
	DONE,
	NUM,
	ID,
//
	IF,
	THEN,
	ELSE,
	END,
//
	DEFINE,
	TYPE_DEFAULT,
//
	IDIV,
	IMOD,
	SE,			// =
	EQ,			// ==
	NE,			// !=
	GT,			// >
	LT,			// <
	LE,			// <=
	GE,			// >=
//
	ADD,		// +
	SUB,		// -
	MUL,		// *
	DIV,		// /
	CON,		// &
	DIS,		// |
//
	EADD,		// +=
	ESUB,		// -=
	EMUL,		// *=
	EDIV,		// /=
	ECON,		// &=
	EDIS,		// |=
//
	INC,		// ++
	DEC,		// --
	AND,		// &&
	OR,			// ||
//
	ROBRACKET,	// (
	SOBRACKET,	// [
	FOBRACKET,	// {
	RCBRACKET,	// )
	SCBRACKET,	// ]
	FCBRACKET,	// }
//
	DOT,		// .
	COMMA,		// ,
	DOTCOMMA,	// ;
//
	BACKSLASH,	//
	QUOTE,		// '	
	DQUOTE,		// "
//
	RVALUE,
	LVALUE,
	DEFINT,

	LABEL,
	GOTO,
	GOFALSE,
	GOTRUE,

	NEG,

	SETFLAG
};

enum {
	TVAL_INT,
	TVAL_FLOAT,
	TVAL_PTR
};

#endif