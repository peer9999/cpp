#include "global.h"

Dtran_t		fa_tran; // temporary table for generating new Dtran
Dstates_t	fa_states; // Dstates - states table
int			nstates,nsize;

void fainit(void) // initialise FA system
{
	nstates=0; nsize=1;
	fa_states = (Dstates_t)malloc(sizeof(Dstates_t)*nsize);
	return;
}

void fafree(void) // deinit
{
	int i;
	for (i=0;i<nstates;i++) {
		if (fa_states[i])
			free(fa_states[i]);
	}
	free(fa_states);
}

int fa_save(char *fn)
{
	int i=0;
	FILE *f;
	if ((f = fopen(fn,"w+"))==NULL) {
		return -1;
	}
	fwrite(&nstates,sizeof(int),1,f);
	for (i=0;i<nstates;i++) {
		fwrite(fa_states[i],sizeof(Dtran_entry_t)*DTRAN_SIZE,1,f);
	}
	fclose(f);
	return 0;
}

int fa_load(char *fn)
{
	int i=0;
	FILE *f;
	if ((f = fopen(fn,"r"))==NULL) {
		return -1;
	}
	fread(&nstates,sizeof(int),1,f);
	if (nstates >= nsize) {
		nsize = nstates+1;
		fa_states = (Dstates_t)realloc(fa_states,sizeof(Dstates_t)*(nsize));
	}
	for (i=0;i<nstates;i++) {
		fa_tran = (Dtran_t)malloc(sizeof(Dtran_entry_t)*DTRAN_SIZE);
		fread(fa_tran,sizeof(Dtran_entry_t)*DTRAN_SIZE,1,f);
		fa_states[i] = fa_tran;
	}
	fclose(f);
	return 0;
}

void tran_flush(int value) // flush temporary Dtran table
{
	int i;
	for (i=0;i<DTRAN_SIZE;i++) {
		fa_tran[i] = value;
	}
	return;
}

void tran_add(int c, int tran) // add new transaction to temporary Dtran
{
	fa_tran[c]=tran;
	return;
}

int *tran_gen(int value) // generate new Dtran from temporary table
{
	fa_tran = (Dtran_t)malloc(sizeof(Dtran_entry_t)*DTRAN_SIZE);
	tran_flush(value); // flush temporary one
	return fa_tran;
}


int states_add(Dtran_t t) // add new state to Dstates
{
	if (nstates >= nsize)
		fa_states = (Dstates_t)realloc(fa_states,sizeof(Dstates_t)*(++nsize));
	fa_states[nstates] = t;
	return nstates++;
}

int transpass(int state, int ch) // calculate target state from current state and current symbol
{
	if (state>=nstates)
		return -1;
	laststate = state;
	return fa_states[state][ch];	
}


