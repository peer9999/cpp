#include "global.h"

#define ERR_CONVERTHEX 0xFA
#define ERR_CONVERTBIN 0xFB

int err_status = 0;

unsigned long bin2int(char* ptr)
{
    char *p = ptr;
    int i;
    unsigned long Rs = 0;
    err_status = 0;
    while (/*(*p!='B') && (*/*p!=0x00/*)*/) {
        if (*p=='1') i=1;
        else if (*p=='0') i=0;
        else {
        err_status = ERR_CONVERTBIN;
        return 0;
        }
        Rs = (Rs << 1) + i;
        p++;
    }
    return Rs;
}

unsigned long hex2int(char* ptr)
{
    char *p1;
    unsigned long i;
    unsigned long Rs;
    p1=ptr;
    Rs=0;
    err_status = 0;
    while (/*(*p1!='H') && (*/*p1!=0x00/*)*/) {
        if ((*p1>='0') && (*p1<='9')) i=*p1 - 48;
        else if ((*p1>='A') && (*p1<='F')) i=*p1 - 55;
        else if ((*p1>='a') && (*p1<='f')) i=*p1 - 32 - 55;
        else {
            err_status = ERR_CONVERTHEX;
            return 0;
        }
        Rs = Rs*16 + i;
        p1++;
    }
    return Rs;
}