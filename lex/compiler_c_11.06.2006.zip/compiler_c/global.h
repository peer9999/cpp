#ifndef __GLOBAL_H_
#define __GLOBAL_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <math.h>

#include "defn.h"
#include "types.h"

// extern variables
extern token_t		tokenval;
extern int			lineno;
extern int			charno;
extern int			err_status;
extern int			laststate;

extern char *i_fname;
extern FILE *i_file;

extern hash_table_t symtable; // symbols table
////////////////////

// init.c
void init(void);
void deinit(void);
void initstates(void);
void add_num_symbols(int state);
void add_alpha_symbols(int state);

// lexer.c
void initlex();
int bufflen(char *s); // calculates buffer length
int loadnext(int part);
int nextch(void);
int nexttoken(void);

void lex_add(char c);
char *lex_gen();
void lex_flush();

void parse_num(char *s,token_t *t);

// finite.c
void fainit(void);
void fafree(void);
int fa_save(char *fn);
int fa_load(char *fn);
void tran_flush(int value);
void tran_add(int c, int tran);
int *tran_gen(int value);
int states_add(Dtran_t t);
int transpass(int state, int ch);

// symbol.c
void initsym(void);
void symfree(void);
void datafree(T data);
int lookup(char *s);
entry_t *get(int id);
int insert(char *s, int tok);
int hashstr(char *s);

// emitter.c
void emit(int t, token_t *tval);

// parser.c
void parse(void);
int stmt(void);
void vars();
void expr(void);
void term(void);
void factor(void);
void match(int t);
int newlabel(void);
token_t *gen_token(int type, int ival, double fval, int *pval);

// utils.h
unsigned long bin2int(char* ptr);
unsigned long hex2int(char* ptr);

// hash.c
hash_index_t hash(int id);
hash_node_t *hash_insert(hash_table_t hash_table, int id, T data);
void hash_delete(hash_table_t hash_table, int id);
hash_node_t *hash_find (hash_table_t hash_table, int id);
hash_table_t hash_init(hash_table_t hash_table);
void hash_free(hash_table_t hash_table);

// error.c
void error(char *s);
void err_expected(int tok);
int repair(int type);

#endif