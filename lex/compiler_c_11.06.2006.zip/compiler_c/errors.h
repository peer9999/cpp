#ifndef __ERRORS_H_
#define __ERRORS_H_

enum {
	PERROR_1
}

#endif