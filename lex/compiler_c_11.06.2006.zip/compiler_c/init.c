/* initialization/deinitialization unit */

#include "global.h"

void init(void) {
	initsym();
	initlex();
	fainit();
//	fa_load("finite.txt");
	initstates();
//	fa_save("finite.txt");
	return;
}

void deinit(void) {
	fafree();
	symfree();
	return;
}


void initstates(void)
{
	Dtran_t t;
	// 0 (begin)
	t=tran_gen(-1); // set error state here
	tran_add(' ',255);
	tran_add('\t',255);
	tran_add('\n',255);
	tran_add('\r',255);
	tran_add(256,256); // set EOF state here
	tran_add('\0',256);
	tran_add('<',1);
	tran_add('=',4);
	tran_add('>',7);
	tran_add('+',28);
	tran_add('-',32);
	tran_add('*',36);
	tran_add('/',39);
	tran_add('&',42);
	tran_add('|',46);
	tran_add('(',50);
	tran_add('[',51);
	tran_add('{',52);
	tran_add(')',53);
	tran_add(']',54);
	tran_add('}',55);
	tran_add('.',56);
	tran_add(',',57);
	tran_add(';',58);
	tran_add('\\',59);
	tran_add('\'',60);
	tran_add('\"',61);
	add_num_symbols(10);
	add_alpha_symbols(26);
	tran_add('0',18); // for 0x...
	states_add(t);
////////////////////////
	// 1 (<,<=)
	t=tran_gen(3);
	tran_add('=',2);
	states_add(t);
	// 2 (<=)
	t=tran_gen(2);
	states_add(t);
	// 3
	t=tran_gen(3);
	states_add(t);
////////////////////////
	// 4 (=,==)
	t=tran_gen(6);
	tran_add('=',5);
	states_add(t);
	// 5 (==)
	t=tran_gen(5);
	states_add(t);
	// 6
	t=tran_gen(6);
	states_add(t);
////////////////////////
	// 7 (>,>=)
	t=tran_gen(9);
	tran_add('=',8);
	states_add(t);
	// 8 (>=)
	t=tran_gen(8);
	states_add(t);
	// 9
	t=tran_gen(9);
	states_add(t);
////////////////////////
	// 10
	t=tran_gen(17); // set finite state here
	add_num_symbols(10);
	add_alpha_symbols(254);
	tran_add('.',11);
	tran_add('E',13);
	states_add(t);
	// 11 (.)
	t=tran_gen(17); // set finite state here
	add_num_symbols(12);
	add_alpha_symbols(254);
	tran_add('E',13);
	states_add(t);
	// 12
	t=tran_gen(17); // set finite state here
	add_num_symbols(12);
	add_alpha_symbols(254);
	tran_add('E',13);
	states_add(t);
	// 13 (E)
	t=tran_gen(254);
	add_num_symbols(14);
	tran_add('+',15);
	tran_add('-',15);
	states_add(t);
	// 14
	t=tran_gen(17); // set finite state here
	add_num_symbols(14);
	add_alpha_symbols(254);
	states_add(t);
	// 15
	t=tran_gen(254);
	add_num_symbols(16);
	states_add(t);
	// 16
	t=tran_gen(17); // set finite state here
	add_num_symbols(16);
	add_alpha_symbols(254);
	states_add(t);
	// 17
	t=tran_gen(17);
	states_add(t);
	// 18
	t=tran_gen(19); // 0x..
	tran_add('x',20);
	tran_add('X',20);
	tran_add('b',23);
	tran_add('B',23);
	states_add(t);
	// 19
	t=tran_gen(19);
	states_add(t);
	// 20
	t=tran_gen(254);
	add_num_symbols(21);
	tran_add('A',21);
	tran_add('B',21);
	tran_add('C',21);
	tran_add('D',21);
	tran_add('E',21);
	tran_add('F',21);
	tran_add('a',21);
	tran_add('b',21);
	tran_add('c',21);
	tran_add('d',21);
	tran_add('e',21);
	tran_add('f',21);
	states_add(t);
	// 21
	t=tran_gen(22); // set finite state here
	add_num_symbols(21);
	add_alpha_symbols(254);
	tran_add('A',21);
	tran_add('B',21);
	tran_add('C',21);
	tran_add('D',21);
	tran_add('E',21);
	tran_add('F',21);
	tran_add('a',21);
	tran_add('b',21);
	tran_add('c',21);
	tran_add('d',21);
	tran_add('e',21);
	tran_add('f',21);
	states_add(t);
	// 22
	t=tran_gen(22);
	states_add(t);
	// 23
	t=tran_gen(254);
	tran_add('0',24);
	tran_add('1',24);
	states_add(t);
	// 24
	t=tran_gen(25);
	add_num_symbols(254);
	add_alpha_symbols(254);
	tran_add('0',24);
	tran_add('1',24);
	states_add(t);
	// 25
	t=tran_gen(25);
	states_add(t);
	// 26
	t=tran_gen(27); // set finite state here
	add_alpha_symbols(26);
	add_num_symbols(26);
	tran_add('_',26);
	states_add(t);
	// 27
	t=tran_gen(27);
	states_add(t);
///////////////////////////
	// 28 (+)
	t=tran_gen(31);
	tran_add('=',29);
	tran_add('+',30);
	states_add(t);
	// 29 (+=)
	t=tran_gen(29);
	states_add(t);
	// 30 (++)
	t=tran_gen(30);
	states_add(t);
	// 31
	t=tran_gen(31);
	states_add(t);
	// 32 (-)
	t=tran_gen(35);
	tran_add('=',33);
	tran_add('-',34);
	states_add(t);
	// 33 (-=)
	t=tran_gen(33);
	states_add(t);
	// 34 (--)
	t=tran_gen(34);
	states_add(t);
	// 35
	t=tran_gen(35);
	states_add(t);
	// 36 (*)
	t=tran_gen(38);
	tran_add('=',37);
	states_add(t);
	// 37 (*=)
	t=tran_gen(37);
	states_add(t);
	// 38
	t=tran_gen(38);
	states_add(t);
	// 39 (/)
	t=tran_gen(41);
	tran_add('=',40);
	states_add(t);
	// 40 (/=)
	t=tran_gen(40);
	states_add(t);
	// 41
	t=tran_gen(41);
	states_add(t);
	// 42 (&)
	t=tran_gen(45);
	tran_add('=',43);
	tran_add('&',44);
	states_add(t);
	// 43 (&=)
	t=tran_gen(43);
	states_add(t);
	// 44 (&&)
	t=tran_gen(44);
	states_add(t);
	// 45
	t=tran_gen(45);
	states_add(t);
	// 46 (|)
	t=tran_gen(49);
	tran_add('=',47);
	tran_add('|',48);
	states_add(t);
	// 47 (|=)
	t=tran_gen(47);
	states_add(t);
	// 48 (||)
	t=tran_gen(48);
	states_add(t);
	// 49
	t=tran_gen(49);
	states_add(t);
///////////////////////////////
	// 50 (()
	t=tran_gen(50);
	states_add(t);
	// 51 ([)
	t=tran_gen(51);
	states_add(t);
	// 52 ({)
	t=tran_gen(52);
	states_add(t);
	// 53 ())
	t=tran_gen(53);
	states_add(t);
	// 54 (])
	t=tran_gen(54);
	states_add(t);
	// 55 (})
	t=tran_gen(55);
	states_add(t);
///////////////////////////////
	// 56 (.)
	t=tran_gen(56);
	states_add(t);
	// 57 (,)
	t=tran_gen(57);
	states_add(t);
	// 58 (;)
	t=tran_gen(58);
	states_add(t);
	// 59 backslash
	t=tran_gen(59);
	states_add(t);
	// 60 (')
	t=tran_gen(60);
	states_add(t);
	// 61 (")
	t=tran_gen(61);
	states_add(t);
	return;
}

void add_num_symbols(int state)
{
	int i;
	for (i=0;i<10;i++) {
		tran_add('0'+i,state);
	}
	return;
}

void add_alpha_symbols(int state)
{
	int i;
	for (i='a';i<='z';i++) {
		tran_add(i,state);
	}
	for (i='A';i<='Z';i++) {
		tran_add(i,state);
	}
	return;
}

void add_all_sumbols(int state)
{
	int i;
	for (i=0;i<=255;i++)
		tran_add(i,state);
	return;
}