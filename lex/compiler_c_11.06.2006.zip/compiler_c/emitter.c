#include "global.h"

// generate output language
void emit(int t, token_t *tval)
{
	switch (t) {
	case ADD:
		printf("+\n"); break;
	case SUB:
		printf("-\n"); break;
	case MUL:
		printf("*\n"); break;
	case DIV:
		printf("/\n"); break;
	case IDIV:
		printf("div\n"); break;
	case IMOD:
		printf("mod\n"); break;
	case SE:
		printf("=\n"); break;
	case NUM:
		if (tval->type==TVAL_INT) {
			printf("push %d\n", tval->ivalue);
		}
		else if (tval->type==TVAL_FLOAT) {
			printf("pushf %G\n", tval->fvalue);
		}
		break;
// ID
	case RVALUE:
		printf("rvalue %s\n",get(tval->ivalue)->lexptr);
		break;
	case LVALUE:
		printf("lvalue %s\n",get(tval->ivalue)->lexptr);
		break;
	case TYPE_DEFAULT:
		printf("define %s\n",get(tval->ivalue)->lexptr);
		break;
//////
	case LABEL:
		printf("label %d\n",tval->ivalue);
		break;
	case GOFALSE:
		printf("gofalse %d\n",tval->ivalue);
		break;
	case GOTRUE:
		printf("gotrue %d\n",tval->ivalue);
		break;
	case GOTO:
		printf("goto %d\n",tval->ivalue);
		break;

	case NEG:
		printf("neg\n");
		break;

	default:
		printf("{token %d, tokenval %d}\n",t,tval->ivalue); 
	}
	return;
}
