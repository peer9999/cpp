/* symbol table */

#include "global.h"

hash_table_t symtable; // symbol table

entry_t keywords[] = {
	"div",		IDIV,
	"mod",		IMOD,
	"if",		IF,
	"then",		THEN,
	"else",		ELSE,
	"end",		END,
	"def",		DEFINE,
	0,			0	
};

/////////////////////////////////////

void initsym(void) 
{
	entry_t *p;
	// allocate memory for lexemes
	if ((symtable = hash_init(symtable))==NULL) // init hash table
		error("Out of memory (hash_init(symtable))");
	for (p = keywords;p->token;p++)
		insert(p->lexptr, p->token);
	return;
}

void symfree(void) 
{
	if (symtable)
		hash_free(symtable);
	return;
}

void datafree(T data)
{
	entry_t *p;
	if (data) {
		p = (entry_t*)data;
		if (p->lexptr)
			free(p->lexptr);
		free(data);
	}
	return;
}

int lookup(char *s)
{
	int shash;
	shash = hashstr(s);
	if (hash_find(symtable,shash)!=NULL)
		return shash;
	return 0;
}

entry_t *get(int id)
{
	return (entry_t*)hash_find(symtable,id)->data;
}

int insert(char *s, int tok)
{
	int len,shash=0;
	entry_t *p;
	len = strlen(s);
	p = (entry_t*)malloc(sizeof(entry_t));
	memset(p,0,sizeof(entry_t));
	p->token = tok;
	p->lexptr = (char*)malloc(sizeof(char)*len+1);
	memset(p->lexptr,0,sizeof(char)*len+1);
	strncpy(p->lexptr,s,len);
	shash = hashstr(p->lexptr);
	if (hash_insert(symtable,shash,p) == NULL)
		error("Out of memory (hash_insert(symtable,shash,p))");
	return shash; // return hash here
}

int hashstr(char *s)
{
	char *p;
	unsigned H=0, g;
	for (p=s; *p != '\0'; p=p+1)
	{
		H=(H<<4)+(*p);
		if (g = H & 0xf0000000) {
			H=H^(g>>24);
			H=H^g;
		}
	}
	return H;
}