/* hash table */

#include "global.h"

#define HASH_TABLE_SIZE		8192
#define compEQ(a,b) (a == b)


int htable_size = HASH_TABLE_SIZE;

hash_index_t hash(int id) 
{
	return (id % htable_size);
}

hash_node_t *hash_insert(hash_table_t hash_table, int id, T data) 
{
    hash_node_t *p, *p0;
    hash_index_t bucket;

   /************************************************
    *  allocate node for data and insert in table  *
    ************************************************/

    /* insert node at beginning of list */
    bucket = hash(id);
    if ((p = malloc(sizeof(hash_node_t))) == 0) 
		return NULL;
    p0 = hash_table[bucket];
    hash_table[bucket] = p;
    p->next = p0;
    p->id = id;
	p->data = data;
    return p;
}

void hash_delete(hash_table_t hash_table, int id) 
{
    hash_node_t *p0, *p;
    hash_index_t bucket;

   /********************************************
    *  delete node containing data from table  *
    ********************************************/

    /* find node */
    p0 = 0;
    bucket = hash(id);
    p = hash_table[bucket];
    while (p && !compEQ(p->id, id)) {
        p0 = p;
        p = p->next;
    }
    if (!p) return;

    /* p designates node to delete, remove it from list */
    if (p0)
        /* not first node, p0 points to previous node */
        p0->next = p->next;
    else
        /* first node on chain */
        hash_table[bucket] = p->next;

	datafree(p->data);
    free(p);
	return;
}

hash_node_t *hash_find (hash_table_t hash_table, int id) 
{
    hash_node_t *p;

   /*******************************
    *  find node containing data  *
    *******************************/

    p = hash_table[hash(id)];
    while (p && !compEQ(p->id, id)) 
        p = p->next;
    return p;
}

hash_table_t hash_init(hash_table_t hash_table)
{
    if ((hash_table = malloc(htable_size * sizeof(hash_node_t *))) == 0) 
		return NULL;
	memset(hash_table,0,htable_size * sizeof(hash_node_t *));
	return hash_table;
}

void hash_free(hash_table_t hash_table)
{
	int i;
	hash_node_t *p;
	for (i=0;i<htable_size;i++) {
		if (hash_table[i]) {
			while (p=hash_table[i]->next) {
				if (p) {
					datafree(p->data);
					free(p);
				}
			}
			datafree(hash_table[i]->data);
			free(hash_table[i]);
		}
	}
	free(hash_table);
	return;
}
