/*

	compiler_c - DFA example

*/

#include "global.h"
//#include <windows.h>

char *i_fname = NULL;
FILE *i_file = NULL;

int main(int argc, char *argv[])
{
//	LARGE_INTEGER li;
//	LONGLONG	llStart;
//	DWORD		dwTime;
	if (argc <= 1) 
		error("no arguments");
	i_fname = argv[1];
	if ((i_file = fopen(i_fname,"r")) == NULL)
		error("can't open input file");
//	QueryPerformanceCounter(&li);
//	llStart = li.QuadPart;
	init();
	parse();
	deinit();
//	QueryPerformanceCounter(&li);
//	dwTime = (DWORD)(li.QuadPart - llStart);
//	printf("Time: %d\n",dwTime/1000);
	if (i_file)
		fclose(i_file);
	return 0;
}