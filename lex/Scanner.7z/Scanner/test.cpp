#include <stdafx.h>

#include <string>
#include <set>
#include <map>

#include <iostream>
#include <fstream>

using namespace std;

#include "token.h"
#include "lexer.h"
#include "scanner.h"

struct TYPE_MAP
{
   ETokenType     TType;
   const char*    pszTName;
};

static TYPE_MAP TypeMap[] =
{
//   {  eTokenTypeNone,               "NULL"               },
   {  eTokenTypeUnknown,            "Unknown"            },
   {  eTokenTypeEOF,                "EOF"                },
   {  eTokenTypeEOL,                "EOL"                },
   {  eTokenTypeWhiteSpace,         "WhiteSpace"         },
   {  eTokenTypeString,             "String"             },
   {  eTokenTypeCharacter,          "Character"          },
   {  eTokenTypeNumeric,            "Numeric"            },
   {  eTokenTypeComment,            "Comment"            },
   {  eTokenTypeEOLComment,         "EOLComment"         },
   {  eTokenTypePunctuation,        "Punctuation"        },
   {  eTokenTypeWord,               "Word"               },
   {  eTokenTypeStatementEnd,       "StatementEnd"       },
   {  eTokenTypeLineContinuation,   "LineContinuation"   },
   {  eTokenTypeOther,              "Other"              }
};

// ��������� ������ ���������� ��� �++.
void Initialize(Lexer& scanner)
{
   TokenTextList*    pReservedWords;

   const nReservedWordElements = CPP_RESERVE_WORD_COUNT;

   char* ReservedWordsArray[nReservedWordElements] = { CPP_RESERVED_WORDS };
   int   nCount;

   pReservedWords = scanner.GetReservedWords();

   for (nCount = 0; nCount < nReservedWordElements; ++nCount)
   {
      pReservedWords->insert(pReservedWords->end(),ReservedWordsArray[nCount]);
   }

   scanner.SetAllowUnderscore(CPP_ALLOW_UNDERSCORE);
   scanner.SetCommentIdentifiers(CPP_COMMENT_IDENTIFIERS);
   scanner.SetEOLCommentIdentifier(CPP_EOL_COMMENT_IDENTIFIER);
   scanner.SetLineContinuationIdentifier(CPP_LINE_CONTINUATION_CHARACTER);
   scanner.SetStringIdentifier(CPP_STRING_IDENTIFIER_CHARACTER,CPP_STRING_ESCAPE_CHARACTER);
   scanner.SetCharacterIdentifier(CPP_CHARACTER_IDENTIFIER,CPP_STRING_ESCAPE_CHARACTER);
   scanner.SetStatementEndIdentifier(CPP_STATEMENT_END_CHARACTER);
}

/*
// ��������� ���������� �++,
void LoadCPPFormat(CCodeParser& parser)
{
   int nCount;
   FormaterStringCol* pFormatStrings;
   const nFormatStringCount = CPP_FORMAT_STRINGS_CODNT;
   const char* FormatStrings[nFormatStringCount]= { CPP_FORMAT_STRINGS };
   const long StringFormatingFlags[] = { CPP_FORMAT_FLAGS };

   pFormatStrings = parser.GetFormatStrings();

   for(nCount = 0; nCount < nFormatStringCount; ++nCount)
   {
      // �������� ������ ������ � �� ����� � ������ FormatStrings.
      pFormatStrings->insert(pFormatStrings->end(),
      FormaterStringCol::value_type(FormatStrings[nCount],StringFormatingFlags[nCount]));
   }
}
*/

int main(int argc,char** argv)
{
   map<string,int>   W, I, O, R, N, C;

   Lexer    Input("test.cpp");

   Initialize(Input);

   // ���������� false ��� ��������� ����������.
//   bool bSuccess = false;

//   CToken   Lexem = Input.GetToken();

//   while (Lexem.GetType() != eTokenTypeEOF)
   while (true)
   {
      CToken   Lexem;
      // �������� ��������� �������,
//      Lexem = Input.GetToken();

      // ������������ ������� � �����������.
      do
      {
         Lexem = Input.GetToken();

cout << TypeMap[Lexem.GetType()].pszTName << " :: " << Lexem << endl;
      }
      while ((Lexem.GetType() == eTokenTypeWhiteSpace) || (Lexem.GetType() == eTokenTypeComment));

      switch (Lexem.GetType())
      {
         case eTokenTypeEOL:
         {
            break;
         }
         case eTokenTypeString:
         {
            break;
         }
         case eTokenTypeCharacter:
         {
            break;
         }
         case eTokenTypeNumeric:
         {
            break;
         }
         case eTokenTypeEOLComment:
         {
            break;
         }
         case eTokenTypePunctuation:
         {
            break;
         }
         case eTokenTypeWord:
         {
            break;
         }
         case eTokenTypeStatementEnd:
         {
            break;
         }
         case eTokenTypeLineContinuation:
         {
            break;
         }
         case eTokenTypeOther:
         {
            break;
         }
         case eTokenTypeUnknown:
         {
            break;
         }
         case eTokenTypeEOF:
         {
            // ���� ������������ ������� �������� ����� �����, ���������� true.
            return true;
         }
         default:
         {
            break;
         }
      }
   }

   return 0;
}

#define CPP_OPERATIONS_COUNT                 (47)
#define CPP_OPERATIONS                                         \
"...", ">>=", "<<=", "+=", "-=", "*=", "/=", "%=", "&=", "^=", \
"|=", ">>", "<<", "++", "--", "->", "&&", "||", "<=", ">=",    \
"==", "!=", "::", ";",  "{", "}", ",", ":", "=", "(", ")",     \
"[", "]", ".", "&", "!", "~", "-", "+", "*", "/", "%", "<",    \
">", "^", "|", "?" 


 ... ,  >>= ,  <<= ,  += ,  -= ,  *= ,  /= ,  %= ,  &= ,  ^= , \
 |= ,  >> ,  << ,  ++ ,  -- ,  -> ,  && ,  || ,  <= ,  >= ,    \
 == ,  != ,  :: ,  ; ,   { ,  } ,  , ,  : ,  = ,  ( ,  ) ,     \
 [ ,  ] ,  . ,  & ,  ! ,  ~ ,  - ,  + ,  * ,  / ,  % ,  < ,    \
 > ,  ^ ,  | ,  ?  
