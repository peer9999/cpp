#ifndef _SCANNER_HPP_
#define _SCANNER_HPP_

#if _MSC_VER > 1000
#pragma warning(disable: 4786)
#pragma once
#endif // MSC VER > 1000

#include <set>
#include <string>
#include <cassert>

using namespace std;

//////////////////////////////////////////////////////////////////////////

#define CPP_LINE_CONTINUATION_CHARACTER      "\\"
#define CPP_ALLOW_UNDERSCORE                 true
#define CPP_COMMENT_IDENTIFIERS              "/*","*/"
#define CPP_EOL_COMMENT_IDENTIFIER           "//"
#define CPP_STRING_IDENTIFIER_CHARACTER      '\"'
#define CPP_CHARACTER_IDENTIFIER             '\''
#define CPP_STRING_ESCAPE_CHARACTER          '\\'
#define CPP_STATEMENT_END_CHARACTER          ';'

//////////////////////////////////////////////////////////////////////////

#define CPP_RESERVE_WORD_COUNT               (60)
#define CPP_RESERVED_WORDS                                        \  
"auto", "bool", "break", "case", "catch", "char", "class",        \
"const", "const_cast","continue", "default", "delete", "do",      \
"double", "dynamic_cast", "else", "enum", "explicit", "extern",   \
"false", "float", "for", "friend", "goto", "if", "inline",        \
"int", "long", "mutable", "namespace", "new", "operator",         \
"private", "protected", "public", "register",                     \
"reinterpret_cast", "return", "short", "signed", "sizeof",        \
"static", "static_cast", "struct", "switch", "template",          \
"this", "throw", "true", "try", "typedef", "typeid",              \
"typename", "union", "unsigned", "using", "virtual", "void",      \
"volatile", "while"                          

//////////////////////////////////////////////////////////////////////////

#define CPP_OPERATIONS_COUNT                 (40)
#define CPP_OPERATIONS                                            \
">>=", "<<=", "+=", "-=", "*=", "/=" , "%=", "&=", "^=", "|=",    \
">>" , "<<" , "++", "--", "->", "&&" , "||", "<=", ">=", "==",    \
"!=" , "="  , "&" , "!" , "~" , "-"  , "+" , "*" , "/" , "%" ,    \
"<"  , ">"  , "^" , "|" , "." , "...", ":" , "::", "," , "?" 

//////////////////////////////////////////////////////////////////////////

#define CPP_DELIMITERS_COUNT                 (7)
#define CPP_DELIMITERS          "[", "]", "{", "}", "(", ")", ";" 

//////////////////////////////////////////////////////////////////////////

class CScanner
{
   private:

      map<char*,int>   Map_W, Map_I, Map_O, Map_R, Map_N, Map_C, Map_S;

      Lexer          _Input;
      ofstream       _OutLexer;
      bool           _Errors;

   public:

       CScanner(const char* const pszFilename);
      ~CScanner();

      void  Run();

   private:

      void Error(const CToken& Lexem);
      void Initialize(Lexer& scanner);

      void ProcessDot();
      void ProcessAmpersand();
      void ProcessExclamation();
      void ProcessMinus();
      void ProcessPlus();
      void ProcessAsterisk();
      void ProcessSlash();
      void ProcessPersent();
      void ProcessLess();
      void ProcessGreat();
      void ProcessHat();
      void ProcessStick();
      void ProcessEqual();
      void ProcessColon();

      void ProcessOperation(const char* const sOP);
      void ProcessDelimiter(const char* const sDL);

      void ProcessStringLiteral   (const string& sText);
      void ProcessCharacterLiteral(const string& sText);
      void ProcessNumericLiteral  (const string& sText);
      void ProcessIdentificator   (const string& sText);
};

//////////////////////////////////////////////////////////////////////////

#endif
