#include <stdafx.h>

#include <string>
#include <set>
#include <map>

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "token.h"
#include "lexer.h"
#include "scanner.h"

//////////////////////////////////////////////////////////////////////////

struct TYPE_MAP
{
   E_TOKEN_TYPE   TType;
   const char*    pszTName;
};

//////////////////////////////////////////////////////////////////////////

static TYPE_MAP TypeMap[] =
{
   {  ETT_NONE,               "Undefined"          },
   {  ETT_EOF,                "EOF"                },
   {  ETT_EOL,                "EOL"                },
   {  ETT_WHITESPACE,         "WhiteSpace"         },
   {  ETT_STRING,             "String"             },
   {  ETT_CHARACTER,          "Character"          },
   {  ETT_NUMERIC,            "Numeric"            },
   {  ETT_COMMENT,            "Comment"            },
   {  ETT_EOL_COMMENT,        "EOLComment"         },
   {  ETT_PUNCTUATION,        "Punctuation"        },
   {  ETT_WORD,               "Word"               },
   {  ETT_STATEMENT_END,      "StatementEnd"       },
   {  ETT_LINE_CONTINUATION,  "LineContinuation"   },
   {  ETT_OTHER,              "Other"              }
};

//////////////////////////////////////////////////////////////////////////

CScanner::CScanner(const char* const pszFilename)
:  _Input(pszFilename)
{
   Initialize(_Input);

   _Errors = false;

   _OutLexer.open("output_lexer.txt");
}

//////////////////////////////////////////////////////////////////////////

CScanner::~CScanner()
{
  _OutLexer.close();

   // [-------------------------------------------]
   
   ofstream    _Out_W;
   
   map<char*,int>::const_iterator it;

   _Out_W.open("output_words.txt");

   for (it = Map_W.begin(); it != Map_W.end(); ++it)
   {
      _Out_W << setw(10) << it->second << " : " << it->first << endl;

   }

   Map_W.clear();

  _Out_W.close();

   // [-------------------------------------------]

   ofstream    _Out_I;
   
   _Out_I.open("output_identificators.txt");

   for (it = Map_I.begin(); it != Map_I.end(); ++it)
   {
      _Out_I << setw(10) << it->second << " : " << it->first << endl;

      char*    pEntry = it->first;

      if (pEntry)
      {
         delete[]  pEntry;
      }
   }

   Map_I.clear();

  _Out_I.close();

   // [-------------------------------------------]

   ofstream    _Out_O;
   
   _Out_O.open("output_operators.txt");

   for (it = Map_O.begin(); it != Map_O.end(); ++it)
   {
      _Out_O << setw(10) << it->second << " : " << it->first << endl;
   }

   Map_O.clear();

  _Out_O.close();

   // [-------------------------------------------]

   ofstream    _Out_R;
   
   _Out_R.open("output_delimiters.txt");

   for (it = Map_R.begin(); it != Map_R.end(); ++it)
   {
      _Out_R << setw(10) << it->second << " : " << it->first << endl;

      char*    pEntry = it->first;

      if (pEntry)
      {
         delete[]  pEntry;
      }
   }

   Map_R.clear();

  _Out_R.close();

   // [-------------------------------------------]

   ofstream    _Out_N;
   
   _Out_N.open("output_numeric.txt");

   for (it = Map_N.begin(); it != Map_N.end(); ++it)
   {
      _Out_N << setw(10) << it->second << " : " << it->first << endl;

      char*    pEntry = it->first;

      if (pEntry)
      {
         delete[]  pEntry;
      }
   }

   Map_N.clear();

  _Out_N.close();

   // [-------------------------------------------]

   ofstream    _Out_C;
   
   _Out_C.open("output_characters.txt");

   for (it = Map_C.begin(); it != Map_C.end(); ++it)
   {
      _Out_C << setw(10) << it->second << " : " << it->first << endl;

      char*    pEntry = it->first;

      if (pEntry)
      {
         delete[]  pEntry;
      }
   }

   Map_C.clear();

  _Out_C.close();

   // [-------------------------------------------]

   ofstream    _Out_S;
   
   _Out_S.open("output_strings.txt");

   for (it = Map_S.begin(); it != Map_S.end(); ++it)
   {
      _Out_S << setw(10) << it->second << " : " << it->first << endl;

      char*    pEntry = it->first;

      if (pEntry)
      {
         delete[]  pEntry;
      }
   }

   Map_S.clear();

  _Out_S.close();

}

//////////////////////////////////////////////////////////////////////////

void CScanner::Initialize(Lexer& scanner)
{
   char*    pReservedWords[CPP_RESERVE_WORD_COUNT] = { CPP_RESERVED_WORDS };
   int      nCount;

   for (nCount = 0; nCount < CPP_RESERVE_WORD_COUNT; ++nCount)
   {
      Map_W.insert(make_pair(pReservedWords[nCount],nCount));
   }

   /*
   for (map<char*,int>::const_iterator it = Map_W.begin(); it != Map_W.end(); ++it)
   {
      cout << it->first << " => " << it->second << endl;
   }
   */

   char*    pOperations[CPP_OPERATIONS_COUNT] = { CPP_OPERATIONS };

   for (nCount = 0; nCount < CPP_OPERATIONS_COUNT; ++nCount)
   {
      Map_O.insert(make_pair(pOperations[nCount],nCount));
   }

   scanner.SetAllowUnderscore(CPP_ALLOW_UNDERSCORE);
   scanner.SetCommentIdentifiers(CPP_COMMENT_IDENTIFIERS);
   scanner.SetEOLCommentIdentifier(CPP_EOL_COMMENT_IDENTIFIER);
   scanner.SetLineContinuationIdentifier(CPP_LINE_CONTINUATION_CHARACTER);
   scanner.SetStringIdentifier(CPP_STRING_IDENTIFIER_CHARACTER,CPP_STRING_ESCAPE_CHARACTER);
   scanner.SetCharacterIdentifier(CPP_CHARACTER_IDENTIFIER,CPP_STRING_ESCAPE_CHARACTER);
   scanner.SetStatementEndIdentifier(CPP_STATEMENT_END_CHARACTER);
}

//////////////////////////////////////////////////////////////////////////

void CScanner::Run()
{
   bool  bFinished = false;

   while (!bFinished)
   {
      CToken   Lexem;

      // ������������ ������� � �����������.
      do
      {
         Lexem = _Input.GetToken();

         // cout << TypeMap[Lexem.GetType()].pszTName << " :: " << Lexem << endl;
      }
      while ((Lexem.GetType() == ETT_WHITESPACE) || (Lexem.GetType() == ETT_COMMENT));

      switch (Lexem.GetType())
      {
         case ETT_EOL:
         {
            break;
         }
         case ETT_STRING:
         {
            ProcessStringLiteral(Lexem.GetTokenText());
            break;
         }
         case ETT_CHARACTER:
         {
            ProcessCharacterLiteral(Lexem.GetTokenText());
            break;
         }
         case ETT_NUMERIC:
         {
            ProcessNumericLiteral(Lexem.GetTokenText());
            break;
         }
         case ETT_EOL_COMMENT:
         {
            break;
         }
         case ETT_PUNCTUATION:
         {
            switch (Lexem[0])
            {
               // Operations
               case '&': { ProcessAmpersand();    break; }
               case '!': { ProcessExclamation();  break; }
               case '-': { ProcessMinus();        break; }
               case '+': { ProcessPlus();         break; }
               case '*': { ProcessAsterisk();     break; }
               case '/': { ProcessSlash();        break; }
               case '%': { ProcessPersent();      break; }
               case '<': { ProcessLess();         break; }
               case '>': { ProcessGreat();        break; }
               case '^': { ProcessHat();          break; }
               case '|': { ProcessStick();        break; }
               case '=': { ProcessEqual();        break; }
               case '.': { ProcessDot();          break; }
               case ':': { ProcessColon();        break; }
               case '~': { ProcessOperation("~"); break; }
               case '?': { ProcessOperation("?"); break; }
               case ',': { ProcessOperation(","); break; }
            
               // Delimiters
               case '{': { ProcessDelimiter("{"); break; }
               case '}': { ProcessDelimiter("}"); break; }
               case '[': { ProcessDelimiter("["); break; }
               case ']': { ProcessDelimiter("]"); break; }
               case '(': { ProcessDelimiter("("); break; }
               case ')': { ProcessDelimiter(")"); break; }
            }

            break;
         }
         case ETT_WORD:
         {
            ProcessIdentificator(Lexem.GetTokenText());
            break;
         }
         case ETT_STATEMENT_END:
         {
            ProcessDelimiter(";");
            _OutLexer << endl;
            break;
         }
         case ETT_LINE_CONTINUATION:
         {
            break;
         }
         case ETT_OTHER:
         {
            Error(Lexem);            
            break;
         }
         case ETT_NONE:
         {
            Error(Lexem);            
            break;
         }
         case ETT_EOF:
         {
            // ���� ������������ ������� �������� ����� �����, ���������� true.
            if (!_Errors)
            {
               _OutLexer << endl << endl  << "//" << "*** Finished. ALL OK !" << endl;
            }
            else
            {
               _OutLexer << endl << endl << "//" << "*** Finished. WITH ERRORS !" << endl;
            }

            bFinished = true;
            break;
         }
         default:
         {
            Error(Lexem);            
            break;
         }
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessDot()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP(".");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != '.')
   {
      Error(Lexem);            
   }

   Lexem = _Input.GetToken();

   if (Lexem[0] != '.')
   {
      Error(Lexem);            
   }

   ProcessOP("...");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessAmpersand()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("&");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("&=");
         break;
      }
      case '&':
      {
         ProcessOP("&&");
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessExclamation()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("!");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("!=");
         break;
      }
      case '(':
      {
         ProcessOP("!");
         ProcessOP("(");
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessMinus()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("-");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("-=");
         break;
      }
      case '-':
      {
         ProcessOP("--");
         break;
      }
      case '>':
      {
         ProcessOP("->");
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessPlus()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("+");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("+=");
         break;
      }
      case '+':
      {
         ProcessOP("++");
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessAsterisk()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("*");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("*=");
         break;
      }
      case '*':
      {
         // Pointer to pointer
         ProcessOP("*");
         ProcessOP("*");
         break;
      }
      case ',':
      {
         // Declaration
         ProcessOP("*");
         ProcessOP(",");
         break;
      }
      case ')':
      {
         // Declaration
         ProcessOP("*");
         ProcessOP(")");
         break;
      }
      case '(':
      {
         // Declaration
         ProcessOP("*");
         ProcessOP("(");
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessSlash()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("/");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != '=')
   {
      Error(Lexem);            
   }

   ProcessOP("/=");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessPersent()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("%");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != '=')
   {
      Error(Lexem);            
   }

   ProcessOP("%=");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessLess()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("<");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP("<=");
         break;
      }
      case '<':
      {
         int nType = _Input.PeekTokenType();

         if (nType != ETT_PUNCTUATION)
         {
            ProcessOP("<<");
            break;
         }

         Lexem = _Input.GetToken();

         if (Lexem[0] == '=')
         {
            ProcessOP("<<=");
         }
         else
         {
            Error(Lexem);
         }
         
         break;
      }
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessGreat()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP(">");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '=':
      {
         ProcessOP(">=");
         break;
      }
      case '>':
      {
         int nType = _Input.PeekTokenType();

         if (nType != ETT_PUNCTUATION)
         {
            ProcessOP(">>");
            break;
         }

         Lexem = _Input.GetToken();

         if (Lexem[0] == '=')
         {
            ProcessOP(">>=");
         }
         else
         {
            Error(Lexem);
         }
         
         break;
      }
      case ':':
      {
         int nType = _Input.PeekTokenType();

         if (nType != ETT_PUNCTUATION)
         {
            Error(Lexem);
            break;
         }

         Lexem = _Input.GetToken();

         if (Lexem[0] == ':')
         {
            ProcessOP(">");
            ProcessOP("::");
         }
         else
         {
            Error(Lexem);
         }
         
         break;
      }   
      default:
      {
         Error(Lexem);
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessHat()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("^");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != '=')
   {
      Error(Lexem);            
   }

   ProcessOP("^=");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessStick()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("|");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   switch (Lexem[0])
   {
      case '|':
      {
         ProcessOP("||");
         break;
      }
      case '=':
      {
         ProcessOP("|=");
         break;
      }
      default:
      {
         Error(Lexem);            
         break;
      }
   }
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessEqual()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP("=");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != '=')
   {
      Error(Lexem);            
   }

   ProcessOP("==");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessColon()
{
   int nType = _Input.PeekTokenType();

   if (nType != ETT_PUNCTUATION)
   {
      ProcessOP(":");
      return;
   }

   CToken   Lexem = _Input.GetToken();

   if (Lexem[0] != ':')
   {
      Error(Lexem);            
   }

   ProcessOP("::");
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessOP(const char* const sOP)
{
   map<char*,int>::const_iterator   it = Map_O.find((char*)sOP);

   if (it == Map_O.end())
   {
      _OutLexer << "O.find() error !" << "[" << sOP << "]" << endl;
      return;
   }

   _OutLexer << "O" << it->second << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessStringLiteral(const string& sText)
{
   for (map<char*,int>::const_iterator it = Map_S.begin(); it != Map_S.end(); ++it)
   {
      if (!strcmp(it->first,(char*)sText.c_str()))
      {  
         _OutLexer << "S" << it->second << " ";
         return;
      }
   }

   char*    pText = new char[sText.length() + 1];

   strcpy(pText,(char*)sText.c_str());

   int   iNext = Map_S.size();

   Map_S.insert(make_pair(pText,iNext));
   _OutLexer << "S" << iNext << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessCharacterLiteral(const string& sText)
{
   for (map<char*,int>::const_iterator it = Map_C.begin(); it != Map_C.end(); ++it)
   {
      if (!strcmp(it->first,(char*)sText.c_str()))
      {  
         _OutLexer << "C" << it->second << " ";
         return;
      }
   }

   char*    pText = new char[sText.length() + 1];

   strcpy(pText,(char*)sText.c_str());

   int   iNext = Map_C.size();

   Map_C.insert(make_pair(pText,iNext));
   _OutLexer << "C" << iNext << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessNumericLiteral(const string& sText)
{
   for (map<char*,int>::const_iterator it = Map_N.begin(); it != Map_N.end(); ++it)
   {
      if (!strcmp(it->first,(char*)sText.c_str()))
      {  
         _OutLexer << "N" << it->second << " ";
         return;
      }
   }

   char*    pText = new char[sText.length() + 1];

   strcpy(pText,(char*)sText.c_str());

   int   iNext = Map_N.size();

   Map_N.insert(make_pair(pText,iNext));
   _OutLexer << "N" << iNext << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessIdentificator(const string& sText)
{
   for (map<char*,int>::const_iterator itW = Map_W.begin(); itW != Map_W.end(); ++itW)
   {
      if (!strcmp(itW->first,(char*)sText.c_str()))
      {  
         _OutLexer << "W" << itW->second << " ";
         return;
      }
   }

   for (map<char*,int>::const_iterator itI = Map_I.begin(); itI != Map_I.end(); ++itI)
   {
      if (!strcmp(itI->first,(char*)sText.c_str()))
      {  
         _OutLexer << "I" << itI->second << " ";
         return;
      }
   }

   char*    pText = new char[sText.length() + 1];

   strcpy(pText,(char*)sText.c_str());

   int   iNext = Map_I.size();

   Map_I.insert(make_pair(pText,iNext));
   _OutLexer << "I" << iNext << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::ProcessDelimiter(const string& sText)
{
   map<char*,int>::const_iterator   it = Map_R.find((char*)sText);

   if (it == Map_R.end())
   {
      _OutLexer << "R.find() error !" << "[" << sText << "]" << endl;
      return;
   }

   _OutLexer << "R" << it->second << " ";
}

//////////////////////////////////////////////////////////////////////////

void CScanner::Error(const CToken& Lexem)
{
   _Errors = true;

   _OutLexer << endl << "Error !" << " :: " << Lexem << endl;
}

//////////////////////////////////////////////////////////////////////////

static void ShowHelp()
{
   printf("-*-   Lexer   C++ Lexer   *   (c)  2013   -*-\n");
   printf("\nC++ Lexical Analyzer\n");
   printf("\nUsage: scanner.exe AnyC++File.cpp\n\n");
}

//////////////////////////////////////////////////////////////////////////

int main(int argc,char** argv)
{
   if (argc != 2)
   {
      ShowHelp();
      return 0;
   }

   if (argc == 2 && ((!strcmp(argv[1],"?")) || (!strcmp(argv[1],"/?")) || (!strcmp(argv[1],"-?")) || (!stricmp(argv[1],"/h")) || (!stricmp(argv[1],"-h"))))
   {
      ShowHelp();
      return 0;
   }

   CScanner    CPPScanner(argv[1]);

   CPPScanner.Run();

   return 0;
}
